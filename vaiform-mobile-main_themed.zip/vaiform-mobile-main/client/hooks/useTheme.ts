import { Colors } from "@/constants/theme";
import { useColorScheme } from "@/hooks/useColorScheme";

type Theme = typeof Colors.light;

export function useTheme() {
  const colorScheme = useColorScheme();
  const scheme = (colorScheme ?? "light") as keyof typeof Colors;
  const baseTheme = Colors[scheme];

  // Ensure backwards-compat + safe fallbacks
  const theme: Theme = {
    ...baseTheme,
    // legacy aliases (some files still expect these)
    text: baseTheme.textPrimary ?? baseTheme.text,
    link: baseTheme.primary ?? baseTheme.link,
    tabIconSelected: baseTheme.primary ?? baseTheme.tabIconSelected,
    buttonText: baseTheme.onPrimary ?? baseTheme.buttonText,
  };

  return {
    theme,
    isDark: scheme === "dark",
  };
}
